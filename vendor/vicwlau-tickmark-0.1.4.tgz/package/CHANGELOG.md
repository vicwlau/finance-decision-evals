# Changelog

## 0.1.4 (2026-10-09)

- Packaging: remove private repository links and paths from the published files. The manifest
  drops its `repository` field, and its scripts call `tsc` from `PATH`. Only docs and source
  comments changed; behaviour is the same as 0.1.3.

## 0.1.3 (2026-10-09)

- Licensed under MIT (was UNLICENSED), so apps that vendor it can be published.

## 0.1.2 (2026-10-09)

- Hovering a paragraph, heading or list item now selects that text when the usual default (the
  nearest `data-tickmark` marker or app component) is more than four times its size. Before, an
  untagged subtitle inside a tagged page section selected the whole section, and the reader had to
  press `]` to reach it. Table cells keep their existing behaviour. Without layout, nothing changes.

## 0.1.1 (2026-10-05)

- Build with TypeScript's own compiler (`tsc`) instead of Bun's bundler: one `.js` and `.d.ts` per
  source file. This removes the staging workaround for a Bun bundler bug, and the package shrinks
  from 160 KB to 56 KB packed.
- Exports point only at `dist/`; the Bun-only `src/` condition is gone. The CLI moved to
  `src/cli.ts` and still installs as `tickmark`.
- Source imports use explicit `.ts` extensions, rewritten to `.js` by `tsc`.
- Distribution is a packed copy in each app's `vendor/`; `publishConfig` is removed.

## 0.1.0 (2026-10-05)

First release as its own package, `@vicwlau/tickmark`, extracted with its history from the app
where it was first built.

- Dev-only comment overlay (Shadow DOM, `Alt+C`), React component, fetch-style server handler, and
  a CLI for agents. Comments are append-only JSONL records (`schema: "tickmark/1"`).
- Compiled `dist/` (ESM plus type declarations) for Node 18+ and any bundler; Bun reads `src/`
  through the `bun` export condition. The `tickmark` bin runs under Node.
- `test/node/smoke.mjs` checks the built package under plain Node.

# tickmark

Dev-only UI comments for coding agents, named after the tickmarks an auditor pencils next to a
figure. Turn on comment mode, click any element, and type what
should change. Each comment is saved as one JSON line in your repo. It carries enough anchor
information (component chain, source file and line, `data-tickmark` id, CSS selector, text) for
an agent to find the code and act. Think Vercel Toolbar comments, but local, stored in git, and
built for agents.

- **Agents:** read [`AGENT.md`](./AGENT.md) for how to consume comments and how to tag UI.
- **Status:** v0.1.4, `@vicwlau/tickmark`. In use in Next.js 16 apps (Turbopack). Works under
  Node 18+, Bun, and any bundler: `dist/` is plain ESM JavaScript with type declarations, compiled
  by `tsc`.

## Using it

| Action | How |
|---|---|
| Comment mode on or off | Toolbar button (bottom right), or `Alt+C` (`⌥C`) |
| Pick a target | Hover. The outline shows what a click will comment on; the label names it. |
| Move up or down the hierarchy | `[` parent, `]` child, or `Alt`+scroll. Works with focus on the toolbar too, but not while typing. |
| Comment | Click, type, then `⌘↵` / `Ctrl+Enter`. Choose `agent` or `human` routing. |
| Cancel, exit | `Esc` closes the comment box, then exits comment mode |
| See comments | The list button. Pins number the open comments on the page. Filter with `This page` / `All` and `Show resolved`. |
| Close a comment | `Resolve` in the list. `Reopen` brings it back. |

**Why `Alt+C`.** C is for comment. `Alt+C` has no default binding in Chrome, Edge, Firefox, or
Safari, or in macOS, Windows, or GNOME shell shortcuts. Shortcuts like `Alt+T` (Firefox's Tools
menu on Windows) and `⌘⇧C` / `Ctrl+Shift+C` (DevTools inspect) were avoided for that reason. On a
Mac, `⌥C` types `ç` in text fields, so the shortcut is ignored while you type in an input. The one
possible clash is a page that sets `accesskey="c"`, which Chrome on Windows triggers with `Alt`.
Change it with the `shortcut` option.

In comment mode, clicks never reach the app: links don't navigate and buttons don't toggle.
Hover still reaches it, so hover-only UI (tooltips) can be commented on. Say in the comment if a
state matters ("with row #003 expanded").

## Installing in an app

**Get the package.** It isn't on any registry. Apps take a packed copy:

1. Here: `bun pm pack`. It builds `dist/` and writes `vicwlau-tickmark-<version>.tgz`.
2. Copy the `.tgz` into the app's `vendor/` folder.
3. In the app's `package.json`: `"@vicwlau/tickmark": "file:vendor/vicwlau-tickmark-0.1.4.tgz"`,
   then `bun install`.

No tokens anywhere, including a cloud build such as Vercel. To update an app, repeat with the new
version's file. While changing tickmark itself, `bun link` here and `bun link @vicwlau/tickmark` in
the app is quicker; never commit the link.

Everyone (Node, Bun, Next.js, Vite, webpack) reads the compiled `dist/`, so no `transpilePackages`
entry is needed.

**Next.js (App Router).** Two pieces, both dev-only:

```tsx
// app/layout.tsx: render inside <body>
import { Tickmark } from "@vicwlau/tickmark/react";
{process.env.NODE_ENV === "development" ? <Tickmark library={["packages/ui/"]} /> : null}
```

```ts
// app/api/tickmark/route.ts: import the handler only in development, so production never bundles it
export const dynamic = "force-dynamic";
let handler: ((req: Request) => Promise<Response>) | undefined;
async function tickmark(req: Request) {
  if (process.env.NODE_ENV === "development") {
    handler ??= (await import("@vicwlau/tickmark/server")).createTickmarkHandler({ file: "docs/feedback/tickmark.jsonl" });
    return handler(req);
  }
  return Response.json({ ok: false, error: "tickmark is dev-only" }, { status: 404 });
}
export { tickmark as GET, tickmark as POST };
```

**Any page, any server.** The overlay is plain DOM in a Shadow DOM, so it needs no framework.
The handler is a fetch-style `(Request) => Promise<Response>`, so it fits Node 18+ (`Request` is
global), Bun, Hono, Next, or anything else that speaks fetch.

```ts
import { mountTickmark } from "@vicwlau/tickmark/overlay";
const dispose = mountTickmark({ endpoint: "/api/tickmark" });

// Server (Node, Bun.serve, Hono, Next, ...)
import { createTickmarkHandler } from "@vicwlau/tickmark/server";
const handler = createTickmarkHandler({ file: "docs/feedback/tickmark.jsonl" });
```

**CLI.** The package installs a `tickmark` command that runs under Node: `npx tickmark list`, or
`bunx tickmark list` in a Bun project (see AGENT.md).

| Option (overlay) | Default | Meaning |
|---|---|---|
| `endpoint` | `/api/tickmark` | Handler URL |
| `library` | `[]` | Path substrings for a shared UI package. Its components show dimmed and are never the default target. |
| `shortcut` | `alt+c` | Toggle. Matched on the physical key (`mod` = ⌘ on Mac, Ctrl elsewhere). |
| `target` | `agent` | Default routing for new comments |
| `maxHops` | `30` | Fiber steps per hover climb |

| Option (handler) | Default | Meaning |
|---|---|---|
| `file` | `docs/feedback/tickmark.jsonl` | Log path, relative to `root` |
| `root` | nearest `.git` ancestor | Where the log lives. Source paths are made relative to it. |
| `appDir` | `process.cwd()` | Base for bundler-relative paths (webpack `./x.tsx`) |
| `allowRemote` | `false` | Answer requests addressed to non-loopback hosts |

## Styling: tickmark's own tokens

The overlay renders in a Shadow DOM with its own inline styles. The host's CSS can't break it,
and it can't leak out. It uses a **compact dark look with one accent**:

- a near-black surface;
- light text;
- a subtle border;
- an 8px radius.

The accent marks everything tickmark adds to the page or wants you to notice:

- the hover outline;
- pins;
- the selected segment of `This page | All`;
- switches;
- focus rings.

| Token | Default | Used for |
|---|---|---|
| `--tickmark-accent` | `#6366f1` (indigo) | The single accent |
| `--tickmark-accent-foreground` | `#ffffff` | Text on the accent |
| `--tickmark-outline` | `var(--tickmark-accent)` | Hover outline on the page |
| `--tickmark-pin` / `--tickmark-pin-foreground` | accent / accent foreground | Numbered pins |
| `--tickmark-focus` | `var(--tickmark-accent)` | Focus rings |
| `--tickmark-surface` | `#0c0c0e` | Toolbar, panel, composer, label |
| `--tickmark-surface-raised` | `#18181b` | Inputs, buttons, kbd chips, list hover |
| `--tickmark-surface-hover` | `#27272a` | Hover on controls, switch off |
| `--tickmark-border` | `#2e2e33` | Borders and dividers |
| `--tickmark-text` / `--tickmark-text-muted` | `#f4f4f5` / `#a1a1aa` | Text |
| `--tickmark-danger` | `#f87171` | Errors, detached tags |
| `--tickmark-radius` / `--tickmark-radius-sm` | `8px` / `6px` | Popovers / controls |
| `--tickmark-font` / `--tickmark-mono` | system UI / system mono | Text, code |
| `--tickmark-shadow` | two soft drop shadows | Floating surfaces |

- **Why indigo.** `#6366f1` has about 4.4:1 contrast against a white page, against a
  near-black page, and as the background for white text. Brighter blues and pinks drop below 3.7:1 on
  white pages, and cyan drops below 3:1.
- **Nothing inherits by default.** `:host { all: initial }` doesn't reset custom properties, so
  every `--tickmark-*` token is declared on `:host`. That blocks values set higher up the page,
  such as a `--tickmark-accent` on `:root`. The host's own tokens (shadcn `--primary` and the
  like) still flow in, but tickmark never reads them.
- **Overriding on purpose.** Target the host element. Outer-page rules beat `:host` rules in the
  cascade, and derived tokens (outline, pin, focus) follow the accent:

  ```css
  tickmark-root { --tickmark-accent: #e11d48; }
  ```

- **Line style tells kinds apart.** Solid for components and markers, dashed for library
  components, dotted for elements.

## How it picks the target

Under the cursor, the core builds a list of **levels**, innermost first:

- the hovered element;
- every `data-tickmark` marker and component around it;
- the structural elements in between: rows, cells, list items, sections, headings, links,
  buttons, and form controls. Generic `div`s and `span`s are skipped. An element is also skipped
  when it is a component's whole output (a `TableRow` that renders only a `<tr>`), because the
  component level outlines the same thing.

How the pieces fit:

- **Adapters.** If the element carries React fiber keys (`__reactFiber$…`), the React adapter
  climbs the fiber tree. Otherwise the DOM adapter walks the element's ancestors. React logic
  lives only in `src/adapters/react.ts`, which imports nothing from React.
- **Markers win.** If any enclosing element has `data-tickmark`, the nearest one is the default
  target, and its value is the anchor's id.
- **Otherwise, the nearest app component.** Each component is classified from where its code
  lives:
  - `node_modules` and framework code are hidden;
  - paths matching `library` are shown dimmed;
  - everything else is app code.
- **Outlines** draw every top-level DOM node of the selected level, one box per client rect.
  Multi-line inline elements get several boxes. Portaled content is included.
- **Stepping.** `]` moves toward the hovered element and `[` moves out, past the 30-hop climb
  limit if needed. Each stays put at its end.
  - **Every press moves the outline.** Consecutive levels that outline exactly the same box are
    one stop. An app component that renders a library `Table` that renders a `<table>` is an
    example.
  - **Which level a stop lands on:** a marker, then an app component, then an element, then a
    library component.
  - **Example.** On a shadcn table, `]` from the table's app component goes body, row, then cell.

### The hover label

One small card above the outline. It flips below, or moves beside, so it never covers the
target. It reads in three steps:

1. **The target**, in bold: the marker id, the component name, or the element (`<tr>`). Next to
   it is a kind chip: `marker` (accent), `component`, `library`, or `element`.
2. **Where it lives**, muted, e.g. `entry-row.tsx:38`. The full path is in the tooltip.
   - An app component shows its own file.
   - A library component shows the app code that uses it ("used at").
   - A marker or element shows its JSX line.
   - It fills in once the source map resolves, and is skipped when unknown.
3. **A short breadcrumb**: two ancestors and the current level, with `↑ n more` for the rest.
   Library levels are dimmed.

Long names are shortened in the middle, with the full text in the tooltip. Key hints are in the
toolbar while comment mode is on, never in the label. The composer's header uses the same card.

## Source locations in React 19 and Next 16 (dev)

What the anchor records, from the clicked element and the selected level:

| Field | Meaning | Example |
|---|---|---|
| `source.definition` | The selected component's root JSX: the file to edit | `components/page.tsx:17` |
| `source.usage` | Where the selected component or marker is rendered by its parent | `components/log-page.tsx:38` |
| `source.element` | Where the clicked element's JSX is, in the nearest app code | `components/page.tsx:19` |

**How it works.**

- React 19 removed `_debugSource`. Dev builds instead give every fiber two fields:
  - `_debugStack`, an `Error` captured where the JSX element was created;
  - `_debugOwner`, the component that created it.
- The JSX call site is the stack frame after `jsxDEV`. For a component's definition, the core uses
  the frame named after the component in the stack of an element it rendered.
- **Client components** have fibers. Their frames point at hashed Turbopack chunks
  (`/_next/static/chunks/*.js`). The overlay fetches `<chunk>.map`, a sectioned index map with
  `ignoreList`, and decodes it in the browser. The result is an exact `file:line:col`.
- **Server Components** have no client fiber. Each appears as a `_debugInfo` entry
  `{ name, env: "Server", owner, stack }` on the fibers it rendered. The DOM nodes it rendered do
  have fibers. Their `_debugStack` holds frames React rebuilt from the server:
  `about://React/Server/file:///…/.next/dev/server/chunks/ssr/<chunk>.js?id=[project]/<path>…`.
  The handler resolves these on the server with Node's `module.findSourceMap`. That is the
  running server's in-memory map, which stays correct after server hot reloads, where the chunk
  files on disk no longer match. Fallbacks, in order:
  - the chunk's map on disk;
  - the `[project]/<path>` module id in the URL (file only, marked `approx`).
- **No private Next.js API is used.** Next's `/__nextjs_original-stack-frames` works for server
  frames but treats browser chunk URLs as external. `captureOwnerStack()` only works during
  render. A build-time attribute plugin would need a new dependency.

**What doesn't work.**

- **Clone-only and pass-through components** have no definition. This covers render-prop
  cloners such as Base UI's triggers, and components that only return `children`. A cloned
  element keeps its creator's stack but takes the cloner as owner, so its frame is skipped. These
  components are classified by where they are rendered.
- **A `displayName` that differs from the function name** hides the named frame, so
  `definition` is missing.
- **`definition` points at the component's first JSX**, not its `function` line.
- **Production builds** carry no debug info. The overlay is disabled there anyway.
- **Without React** (or React ≤ 18 without `_debugSource`), anchors have no `source`. Markers,
  selectors, and text still work.

## Records and storage

`docs/feedback/tickmark.jsonl`, one JSON object per line, **append-only**. It is its own file,
so other feedback logs in the host app's `docs/feedback/` folder never collide with it.

- `note`: `{ type, schema: "tickmark/1", id, ts, target: "agent"|"human", by, page: { url, path, title }, viewport: { width, height, dpr, scrollX, scrollY }, anchor, comment }`
- `reply`: `{ type, schema, id, ts, ref, by, text }`
- `status`: `{ type, schema, id, ts, ref, to: "open"|"answered"|"resolved"|"orphaned"|"archived", by, why? }`

`anchor`:
`{ target: { kind: "marker"|"component"|"element", name, env?, role?, nth? }, marker?, within?, chain: [{ name, kind, env?, role? }], selector, text?, element: { tag, selector, text?, role?, label? }, rect, source?: { definition?, usage?, element? }, framework: "react"|"dom" }`.
A note's top-level `target` (`agent` or `human`) is its routing: who should act on it.
`anchor.target` is the thing that was selected.

**Reading folds the stream.**

- A note's `status` is its last `status` event (default `open`).
- `created` is the note's `ts`; `updated` is its newest event's `ts`.
- `replies` and `history` collect its events.

The handler's GET and `cli.ts list --json` return this folded view.

**Why append events, not rewrite lines.**

- The overlay and an agent's CLI can write at the same time without clobbering each other.
- Git diffs are pure additions.
- The history of who resolved what stays in the file.
- The cost is a file that only grows. A `compact` command is on the list below.

## Re-finding anchors

On load, each comment is re-found in this order. The first confident match wins.

1. **`data-tickmark` id.** Unique on the page, or the stored `nth`.
2. **Component chain.** Instances with the same name whose ancestor names contain the stored
   chain in order. Ties break on text, then `nth`.
3. **CSS selector.** It must also match the stored text when there is one.
4. **Text.** A unique element with the same tag and text.

If nothing matches, the comment is **detached**: it stays in the list with a `detached` tag and
gets no pin. It is never pinned to a guessed element. Selectors use markers, ids, test ids, ARIA
labels, and tag positions. They skip utility classes and generated ids (`useId`, `base-ui-…`).

## Performance (measured)

Measured in headless Chrome on a Next.js 16 dev app (Turbopack), sweeping the cursor over every
visible element:

| Page | Elements | Per new hovered element | Per frame (hover + outline + pins) | Prewarm on toggle |
|---|---|---|---|---|
| A list page | 466 | 0.08 ms avg, 0.30 ms max | 0.39 ms avg, 2.4 ms max | 29 ms (309 components) |
| The home page | 272 | 0.08 ms avg, 0.20 ms max | 0.41 ms avg, 1.3 ms max | 27 ms (253 components) |

How it stays fast:

- Hover work runs once per animation frame, and only when the element under the cursor changes.
- The fiber climb stops at 30 hops. `[` past the end extends it.
- Results are cached per element in a `WeakMap`.
- Component classification is cached per component type and prewarmed when comment mode turns on.
- With comment mode off, the only work is one `keydown` listener.

## Tests

- `bun test` runs:
  - the unit tests (schema, stack and source-map parsing, handler, level construction and
    stepping, label model);
  - the **browser tests** in `test/browser/`.
- **Browser tests.** These build a small React 19 dev fixture with `Bun.build`, serve it from an
  in-process `Bun.serve`, and drive a private headless Chrome over the DevTools protocol. They
  check that `[` / `]` reach a table row and then a cell, with comment mode turned on by `Alt+C`
  and by clicking the toolbar, on a shadcn-style table and a plain-JSX table. They also check that
  brackets type normally in the composer.
- **When they skip.** Without Chrome they skip. `TICKMARK_E2E=0` also skips them, and
  `TICKMARK_CHROME=<path>` picks a browser.
- **`react` and `react-dom`** for the fixture come from a host app, because this repo installs
  nothing: `TICKMARK_REACT_HOST=<app folder>`, else a fallback host folder set in
  `test/browser/fixture-server.ts`. Without either, the browser tests skip.
- **Node smoke test.** `bun run build && node test/node/smoke.mjs` imports `dist/` under plain
  Node, round-trips the handler and runs the CLI.
- **Build.** `bun run build` is just `tsc -p tsconfig.build.json` (it needs `tsc` on `PATH`): one
  `.js` and one `.d.ts` per source file. Source files import each other with `.ts` extensions, which `tsc` rewrites to `.js`
  (`rewriteRelativeImportExtensions`), because Node needs explicit extensions.

## Dev-only and safety

- **Client.** `<Tickmark>` renders nothing in production, and the overlay module is never
  imported there. Verified: a production build of a Next.js app that uses it contains no overlay
  code, and `/api/tickmark` answers 404.
- **Handler.** It returns 404 when `NODE_ENV=production`. It answers only on loopback hosts
  unless `allowRemote` is set.
- **POSTs** must be `application/json` from the same origin. This blocks drive-by writes from
  other sites.
- **Source maps** are read only from inside the repo root.

## Revisit later (known gaps)

- **Portals.** Hovering inside a portal climbs to its owner. A component's outline includes its
  portaled nodes, which can draw boxes far apart. No special handling for focus traps that steal
  focus from the comment box.
- **Fixed and transformed elements.** Boxes come from `getClientRects()`, so they're right
  per frame. Pins on fixed elements can still overlap the app's own fixed UI.
- **Text-only components** (a component that returns a string) have no DOM node to outline.
- **`display: contents`** elements fall back to their children's boxes, two levels deep.
- **iframes and closed shadow roots** aren't entered.
- **Hover-only state** can't be held while clicking. The commenter describes it in text.
- **Duplicate markers** (the same `data-tickmark` id twice on a page) rely on `nth`.
- **Client hot reload.** Frames from hot-reloaded client chunks resolve if their maps are
  served. Tested in one Next.js app only.
- **Log growth.** Add `cli.ts compact` (fold, then rewrite resolved threads) once the log is
  large.
- **Touch devices.** Tap to comment works, but there's no hover preview and no level stepping.
- **Same-box stops.** Grouping same-box levels means a library component can't be selected when
  an app component or element covers exactly the same box. The comment lands on the app level,
  whose `usage` source points at the library call anyway.
- **Server-rendered tables in the browser test.** The fixture is a client React app. Real Server
  Component levels (`_debugInfo`) are covered by unit fakes and use in a Next.js app, not the
  browser test.

## Distribution and open items

- **Distribution:** packed copies in each app's `vendor/` (owner's choice, 2026-10-05), so no app
  needs a registry token. GitHub Packages remains possible later.
- **License:** MIT (see `LICENSE`).
- **Coverage:** only Turbopack hosts are verified. Test the overlay with Vite and webpack hosts.

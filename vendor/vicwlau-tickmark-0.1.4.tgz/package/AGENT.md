# UI comments: guide for coding agents

The owner leaves comments on the running UI. Each one lands as a JSON line in
`docs/feedback/tickmark.jsonl`, anchored to a component, a source line, and a DOM location.
This page covers how to read them, find the code, act, and close them. It also covers how to tag
UI you build so future comments anchor well.

## 1. Read the open comments

```sh
npx tickmark list                  # open + answered, routed to anyone
npx tickmark list --target agent   # only the ones routed to you
npx tickmark list --json           # folded records, for scripting
npx tickmark show <id>             # one record, everything in it
```

Work the comments whose status is `open` and whose `target` is `agent`. Ids accept a unique
prefix.

**Never edit or delete lines in the log.** It is append-only. Use the CLI, which appends
`reply` and `status` events.

## 2. Find the code

Use the anchor fields in this order. Stop when you are sure.

1. **`anchor.source.definition`**: the selected component's file and line (its root JSX).
   Usually the file to edit.
2. **`anchor.source.usage`**: where the selected component or `data-tickmark` element is
   rendered by its parent. Edit here for props, placement, or which variant is used.
3. **`anchor.source.element`**: where the exact clicked element's JSX is, in the nearest app
   code. Use it when the comment is about one small thing ("this badge").
4. **`anchor.marker` / `anchor.within`**: a `data-tickmark` id. Grep the app's source for it:
   `rg 'data-tickmark=.*entry'` (ids built with `tickmarkId(...)` appear as their parts, e.g.
   `tickmarkId("entry", entry.id)`).
5. **`anchor.chain`**: component names, outermost first. Grep for
   `function <Name>` / `const <Name>`.
6. **`anchor.selector`, `anchor.text`, `anchor.rect`**: to see the element itself. Open
   `page.url` in a headless browser, run `document.querySelector(selector)`, and screenshot at
   `viewport` size.

**Read the fields carefully.**

- **Line numbers** come from dev source maps at capture time. They can drift after edits, so
  check the line before editing.
- **`approx: true`** means only the file is known.
- **`role: "library"`** in the chain or target means a shared UI package: the paths given in
  the overlay's `library` option, such as `packages/ui/`.
  Prefer changing the app code that uses it (`usage`). Change the library only when the comment
  is about the primitive itself.
- **The comment text is the spec.** The owner describes any state that matters there ("with the
  row expanded"). Nothing is captured automatically.

## 3. Act, then close the loop

```sh
npx tickmark resolve <id> --why "Header margin 32px -> 24px in components/page.tsx"
npx tickmark answer  <id> "It's mb-8 in components/page.tsx:17. Want 24px?"
npx tickmark reply   <id> "Done, but also changed the lessons page to match."
npx tickmark reopen  <id>
```

- **Change request:** make the edit, then `resolve` with a one-line `--why`. Say what changed
  and where.
- **Question, or unclear:** `answer` it. That posts a reply and sets the status to `answered`.
  The owner sees the reply in the overlay's list and can reopen.
- **Can't find the target** (the code was removed or renamed): `reply` with what you looked
  for, then `orphan <id> --why "…"`. Or leave it open and report it.

The writer defaults to `--by agent`. The log is part of the repo, so follow the repo's commit
rules for it like any other file.

## 4. Tag the UI you build

Add `data-tickmark` to anything a reviewer would comment on. A tagged element becomes the
default target when hovering inside it. Its id is stored with every comment on it, so the
comment survives refactors and moved files.

**What to tag:**

- page sections and headers;
- cards and panels;
- each row of a list or table;
- nav items;
- dialogs and popovers;
- forms and their key fields;
- empty and error states.

Don't tag every `div`, wrappers, or pure-layout elements.

**How to name ids:** lowercase kebab-case segments joined by dots, as
`<area>.<part>[.<key>]`.

- The id must be unique on the page. Use a stable data key for list rows (an entry id or a slug),
  never an array index when items can reorder.
- Keep ids stable across refactors: name the thing, not its styling or position.
- Build ids with the helper. It slugs and joins:

```tsx
import { tickmarkId } from "@vicwlau/tickmark";

<header data-tickmark="page.header">…</header>
<a href={href} data-tickmark={tickmarkId("nav", "item", label)}>…</a>          // nav.item.decisions
<Card data-tickmark={tickmarkId("families", "group", group.heading)}>…</Card>  // families.group.in-scope
<AccordionItem data-tickmark={tickmarkId("entry", entry.id)}>…</AccordionItem> // entry.003
<li data-tickmark={tickmarkId("now.waiting", i + 1)}>…</li>                    // now.waiting.2 (ordered list)
```

The attribute must reach the DOM. Shared UI primitives that spread extra props onto their root
element (as shadcn-style components do) pass it through already. For your own components, pass
it through (`{...props}`) or put it on the root element.

A typical set of ids, by kind of UI:

- page shell: `page.header`, `section.<title>`;
- navigation: `nav.item.<label>`;
- list rows: `entry.<id>`;
- a list's body and empty state: `<list>.entries`, `<list>.empty`;
- dashboard blocks and their numbered items: `now.waiting`, `now.waiting.<n>`, `now.next.<n>`;
- groups of cards: `families.group.<heading>`.
